package com.hpe.restservice.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    // @GeneratedValue is not typically used with String type IDs, but is common with Integer IDs.
    private String employeeId;

    @PrePersist   // Generates a UUID before the entity is saved to the DB to ensure ID uniqueness.
    public void prePersist(){
        if (this.employeeId == null){
            this.employeeId = UUID.randomUUID().toString(); // For MSA integration and independence from indexing dependency by DB
                                                            // In this case, remove @GeneratedValue
        }
    }

    private String firstName;
    private String lastName;
    private String email;
    private String title;

}
