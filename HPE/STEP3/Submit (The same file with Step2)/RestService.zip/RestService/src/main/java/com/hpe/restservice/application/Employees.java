package com.hpe.restservice.application;

import com.hpe.restservice.domain.Employee;
import com.hpe.restservice.infrastructure.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class Employees {

    private final EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees(){
        return employeeRepository.findAll();
    }

    public Employee addEmployee(Employee employee){
        return employeeRepository.save(employee);
    }

    public Employee getEmployeeById(String id){
        return employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found with id: " + id));
    }

    public Employee updateEmployee(Employee updatedEmployee){
        if (!employeeRepository.existsById(updatedEmployee.getEmployeeId())){
            throw new IllegalArgumentException("Employee not found with id: " + updatedEmployee.getEmployeeId());
        } else {
            return employeeRepository.save(updatedEmployee);
        }
    }

    public void deleteEmployee(String id){
        if (!employeeRepository.existsById(id)){
            throw new IllegalArgumentException("Employee not found with id: "+ id);
        }
        employeeRepository.deleteById(id);
    }
}
