package com.hpe.restservice.dto;

import com.hpe.restservice.domain.Employee;
import org.modelmapper.ModelMapper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {
    private String employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String title;


    public static EmployeeDTO of(Employee employee, ModelMapper modelMapper){
        return modelMapper.map(employee, EmployeeDTO.class);
        // Receives the employee entity object as a parameter, and when the data type of the Employee object and the name of
        // the member variable are the same, copies the value to EmployeeDTO and returns it. It can be called even without
        // creating an EmployeeDTO object by declaring it as a static method.
    }

    public Employee toEntity(ModelMapper modelMapper){
        return modelMapper.map(this, Employee.class);
    }

}
