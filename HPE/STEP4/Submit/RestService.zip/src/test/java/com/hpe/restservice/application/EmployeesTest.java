package com.hpe.restservice.application;

import com.hpe.restservice.domain.Employee;
import com.hpe.restservice.infrastructure.EmployeeRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // For unit tests using Mockito with @Mock and @InjectMocks to speed up tests.
                                    // @SpringBootTest is suitable for integration testing as it loads the full Spring context.
class EmployeesTest {

    // Mock the EmployeeRepository to define its behavior in the test
    @Mock
    private EmployeeRepository employeeRepository;

    // Inject the mocked EmployeeRepository into the Employees instance for testing
    @InjectMocks
    private Employees employees;


    int count = 4;

    // Create a list of UUIDs
    private final List<String> ids = generateUUIDList(count);

    // UUID generation method
    private String generateUUID(){
        return UUID.randomUUID().toString();
    }

    // UUID list creation method
    private List<String> generateUUIDList(Integer cnt){
        return Stream.generate(this::generateUUID)
                .limit(cnt)
                .collect(Collectors.toList());
    }


    // Create a list of employee information
    private final List<List<String>> empList = List.of(
            List.of("Heeju", "Yang", "heeju_yang@hpe.com", "Project Manager"),
            List.of("Chuck", "Norris", "chuck_norris@hpe.com", "Data Analyst"),
            List.of("Mac", "Lovin", "mac_lovin@hpe.com", "Developer"),
            List.of("Quokka", "Cola", "quokka_cola@hpe.com", "Therapist")
    );

    // Create a list of Employee objects
    private final List<Employee> finalList = IntStream.range(0, empList.size())
            .mapToObj(i -> new Employee(ids.get(i), empList.get(i).get(0), empList.get(i).get(1),
                    empList.get(i).get(2), empList.get(i).get(3)))
            .toList();

    @Test
    @DisplayName("FindAll test: Employees should be returned correctly")
    void getAllEmployees() {
        // Given: Mock the repository to return the predefined list of employees
        when(employeeRepository.findAll()).thenReturn(finalList);

        // When: Call the method under test
        List<Employee> result = employees.getAllEmployees();

        // Then: Verify that the result matches the expected list
        assertEquals(finalList.size(), result.size(), "The size of the employee list should be equal.");

        for (int i = 0; i < finalList.size(); i++) {
            Employee expected = finalList.get(i);
            Employee actual = result.get(i);

            assertEquals(expected.getEmployeeId(), actual.getEmployeeId(), "Employee IDs should match.");
            assertEquals(expected.getFirstName(), actual.getFirstName(), "First names should match.");
            assertEquals(expected.getLastName(), actual.getLastName(), "Last names should match.");
            assertEquals(expected.getEmail(), actual.getEmail(), "Emails should match.");
            assertEquals(expected.getTitle(), actual.getTitle(), "Titles should match.");
        }
    }

    @Test
    void addEmployee() {
        // Given: Create a new Employee object and mock the repository to return this employee when saved
        String id = "uuid-1234";
        Employee newEmployee = new Employee(id, "Tom", "Cat", "tom_cat@hpe.com", "MLOps");
        when(employeeRepository.save(any(Employee.class))).thenReturn(newEmployee); // `any()` matches any value of the specified type.
                                                                                    // No need to specify anything inside `()`
                                                                                    // unless you want to specify the type explicitly,
                                                                                    // e.g., `any(Employee.class)`.
        // When: Call the method under test
        Employee result = employees.addEmployee(newEmployee);
        // Regardless of the Employee object passed to save(), the mocked save() method always returns newEmployee.
        // Thus, the return value of addEmployee() will match newEmployee as configured in the mock setup.

        // Then: Verify that the result matches the expected employee
        assertEquals(newEmployee.getEmployeeId(), result.getEmployeeId(), "Employee IDs should match.");
        assertEquals(newEmployee.getFirstName(), result.getFirstName(), "First names should match.");
        assertEquals(newEmployee.getLastName(), result.getLastName(), "Last names should match.");
        assertEquals(newEmployee.getEmail(), result.getEmail(), "Emails should match.");
        assertEquals(newEmployee.getTitle(), result.getTitle(), "Titles should match.");
    }

    @Test
    void getEmployeeById() {
        // Given: Create an Employee object and mock the repository to return this employee when findById is called
        String id = "uuid-1234";
        Employee expectedEmployee = new Employee(id, "Tom", "Cat", "tom_cat@hpe.com", "MLOps");
        when(employeeRepository.findById(id)).thenReturn(Optional.of(expectedEmployee));
        // findById() returns Optional<Employee>. Directly returning expectedEmployee would cause a type mismatch,
        // e.g., thenReturn(expectedEmployee) instead of thenReturn(java.util.Optional.of(expectedEmployee)).

        // When: Call the method under test
        Employee result = employees.getEmployeeById(id);

        // Then: Verify that the result matches the expected employee
        assertEquals(expectedEmployee.getEmployeeId(), result.getEmployeeId(), "Employee IDs should match.");
        assertEquals(expectedEmployee.getFirstName(), result.getFirstName(), "First names should match.");
        assertEquals(expectedEmployee.getLastName(), result.getLastName(), "Last names should match.");
        assertEquals(expectedEmployee.getEmail(), result.getEmail(), "Emails should match.");
        assertEquals(expectedEmployee.getTitle(), result.getTitle(), "Titles should match.");
    }

    @Test
    void updateEmployee() {
        // Given: Create an existing Employee and an updated Employee object
        String id = "uuid-1234";
        Employee existingEmployee = new Employee(id, "Tom", "Cat", "tom_cat@hpe.com", "MLOps");
        Employee updatedEmployee = new Employee(id, "Tom", "Cat", "tom_cat@hpe.com", "DevOps");


        // Given: Assume that the employee exists
        when(employeeRepository.existsById(id)).thenReturn(true);
        // Mock the repository to return the updated employee when save is called
        when(employeeRepository.save(updatedEmployee)).thenReturn(updatedEmployee);

        // When: Call the method under test
        Employee result = employees.updateEmployee(updatedEmployee);

        // Then: Verify that the result matches the updated employee
        assertEquals(updatedEmployee.getEmployeeId(), result.getEmployeeId(), "Employee IDs should match.");
        assertEquals(updatedEmployee.getFirstName(), result.getFirstName(), "First names should match.");
        assertEquals(updatedEmployee.getLastName(), result.getLastName(), "Last names should match.");
        assertEquals(updatedEmployee.getEmail(), result.getEmail(), "Emails should match.");
        assertEquals(updatedEmployee.getTitle(), result.getTitle(), "Titles should match.");
    }

    @Test
    void deleteEmployee() {
        // Given: Create an ID for an existing employee
        String id = "uuid-1234";
        // Assume that the employee exists
        when(employeeRepository.existsById(id)).thenReturn(true);

        // When: Call the method under test
        employees.deleteEmployee(id);

        // Then: Verify that deleteById was called with the correct ID
        verify(employeeRepository).deleteById(id);  // verify checks if a specific method on a mock was called with
                                                    // the expected arguments, ensuring correct interaction.
    }
}