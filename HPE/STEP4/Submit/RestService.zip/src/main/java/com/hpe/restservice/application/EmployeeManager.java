package com.hpe.restservice.application;

import com.hpe.restservice.domain.Employee;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EmployeeManager {

    private final Employees employees;

    @Autowired
    public EmployeeManager(Employees employees) {
        this.employees = employees;
    }

    /***
     * Initializes the EmployeeManager bean with sample employees.
     * This method is called after the bean's dependency injection is complete.
     */
    @PostConstruct // Used by the Spring Framework to automatically call a method after
                   // the bean has been initialized. This method is called
                   // after the bean's dependency injection is complete, and it is useful for
                   // performing initialization or configuration tasks for the bean.
    public void init(){

        /***
         private String employeeId;
         private String firstName;
         private String lastName;
         private String email;
         private String title;
         ***/

        try {
            employees.addEmployee(new Employee(null, "Heeju","Yang","heeju_yang@hpe.com", "Project Manager"));
            employees.addEmployee(new Employee(null, "Chuck","Norris","chuck_norris@hpe.com", "Data Analyst"));
            employees.addEmployee(new Employee(null, "Mac","Lovin","mac_lovin@hpe.com", "Developer"));
            employees.addEmployee(new Employee(null, "Quokka","Cola","quokka_cola@hpe.com", "Therapist"));

            log.info("EmployeeManager bean has been initialized.");
        } catch (Exception e) {
            // Logging or exception handling
            log.error("An error occurred during EmployeeManager initialization: ", e);

        }
    }

}
