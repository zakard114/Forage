package com.hpe.restservice.presentation;

import com.hpe.restservice.application.Employees;
import com.hpe.restservice.domain.Employee;
import com.hpe.restservice.dto.EmployeeDTO;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@RequestMapping("/employees")
public class EmployeeController {

    private final Employees employees;
    private final ModelMapper modelMapper;

    @GetMapping
    public List<EmployeeDTO> getAllEmployees(){
        return employees.getAllEmployees().stream()
                .map(employee -> EmployeeDTO.of(employee, modelMapper))
                .collect(Collectors.toList());
    }

    @PostMapping
    public EmployeeDTO createEmployee(@RequestBody EmployeeDTO employeeDTO){
        // Convert DTO to Entity
        Employee employee = employeeDTO.toEntity(modelMapper);
        // Save the employee entity to trigger UUID generation
        Employee savedEmployee = employees.addEmployee(employee);
        // Convert saved entity back to DTO for the response
        return EmployeeDTO.of(employee, modelMapper);
    }

    @GetMapping("/{id}")
    public EmployeeDTO getEmployeeById(@PathVariable String id){
        Employee employee = employees.getEmployeeById(id);
        return EmployeeDTO.of(employee, modelMapper);
    }

    @PutMapping("/{id}")
    public EmployeeDTO updateEmployee(@PathVariable String id, @RequestBody EmployeeDTO employeeDTO){
        Employee employee = employeeDTO.toEntity(modelMapper);
        employee.setEmployeeId(id);
        Employee updatedEmployee = employees.updateEmployee(employee);
        return EmployeeDTO.of(updatedEmployee, modelMapper);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable String id){
        employees.deleteEmployee(id);
    }

}
